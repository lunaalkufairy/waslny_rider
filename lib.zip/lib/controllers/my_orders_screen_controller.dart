import 'package:get/get.dart';

class MyOrdersScreenController extends GetxController {
  List<String>? orders = ['Order 1', 'Order 2', 'Order 3'];
}
